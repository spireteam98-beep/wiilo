
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useFirebaseAuth } from '@/contexts/firebase-auth';
import { useEffect } from 'react';
import { getUserProfile } from '@/lib/user';

// Facebook Icon Component
const FacebookIcon = () => (
  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
    <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
  </svg>
);

export default function SignUpPage() {
  const router = useRouter();
  const { user, loading, signInWithGoogle } = useFirebaseAuth();
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [message, setMessage] = useState('');
  const [formError, setFormError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Redirect if already logged in via Firebase
  useEffect(() => {
    if (user) router.push('/wallet');
  }, [user, router]);

  const handleGoogleLogin = async () => {
    setIsLoading(true);
    try {
      const u = await signInWithGoogle();
      if (u) {
        // Check for existing profile in Firestore. If missing, send user to complete profile step.
        try {
          const profile = await getUserProfile(u.uid);
          if (profile) {
            router.push('/wallet');
          } else {
            router.push('/account/complete');
          }
        } catch (err) {
          console.error('Error checking profile:', err);
          router.push('/account/complete');
        }
      }
    } catch (error) {
      console.error('Google login error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    // require user to be signed-in for this flow (we have Google sign-in as the primary auth)
    if (!user) {
      setFormError('Please sign in with Google (top button) to create an account — or sign in and then complete the fields.');
      return;
    }

    // basic validation
    if (!fullName.trim() || !email.trim()) {
      setFormError('Please fill Full Name and Email.');
      return;
    }

    setIsLoading(true);
    try {
      const { setUserProfile } = await import('@/lib/user');
      const names = fullName.trim().split(/\s+/);
      const firstName = names.shift() ?? '';
      const lastName = names.join(' ');

      await setUserProfile(user.uid, {
        firstName,
        lastName,
        displayName: fullName,
        email,
        whatsapp: phone,
        // keep message as additional profile metadata
        // use a small field name so it doesn't block the profile shape
        message: message || undefined,
      });

      router.push('/wallet');
    } catch (err) {
      console.error('Failed to save profile', err);
      setFormError('Failed to save profile. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-[#F97316] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black flex justify-center items-start md:items-center">
      {/* Background with orange ambient glow */}
      <div 
        className="w-full max-w-md relative min-h-screen flex items-start md:items-center justify-center px-4 py-6 md:px-6 md:py-12"
        style={{
          background: `
            radial-gradient(ellipse at top, rgba(249, 115, 22, 0.15) 0%, transparent 50%),
            radial-gradient(ellipse at bottom, rgba(249, 115, 22, 0.2) 0%, transparent 50%),
            radial-gradient(ellipse at left, rgba(249, 115, 22, 0.1) 0%, transparent 40%),
            radial-gradient(ellipse at right, rgba(249, 115, 22, 0.1) 0%, transparent 40%),
            #0A0A0A
          `,
        }}
      >
        {/* Card Container (taller, portrait 'stand' layout) */}
        <div 
          className="w-full max-w-[520px] p-6 md:p-8 rounded-[34px] shadow-2xl flex flex-col items-stretch justify-between h-[calc(100vh-48px)] md:h-[760px] max-h-[92vh] md:max-h-[92vh] overflow-hidden mt-6 md:mt-0"
          style={{
            background: 'linear-gradient(180deg, rgba(8,8,10,0.98) 0%, rgba(11,11,13,0.95) 100%)',
            boxShadow: `
              0 70px 120px -20px rgba(249, 92, 16, 0.45),
              inset 0 2px 0 rgba(255,255,255,0.02),
              inset 0 -18px 60px rgba(255,120,20,0.03)
            `,
            border: '1px solid rgba(255,255,255,0.03)',
            height: '760px',
            maxHeight: '92vh',
          }}
        >
          {/* Facebook Login Button */}
          <button
            onClick={handleGoogleLogin}
            disabled={isLoading}
            className="w-full flex items-center justify-center gap-3 px-5 py-4 rounded-full bg-[#4285F4] hover:bg-[#357AE8] text-white font-semibold text-sm transition-all duration-200 mb-6 disabled:opacity-50"
          >
            {/* Google icon (simple) */}
            <svg className="w-5 h-5" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
              <path fill="#EA4335" d="M24 9.5c3.9 0 7.3 1.3 10 3.6l7.4-7.4C36.6 2.3 30.6 0 24 0 14.7 0 6.9 4.7 2.7 11.6l8.9 6.9C13.9 12 18.6 9.5 24 9.5z" />
              <path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.6H24v9.1h12.8c-.6 3-2.6 5.6-5.4 7.3l8.7 6.7c5-4.6 8.4-11.2 8.4-18.5z" />
              <path fill="#FBBC05" d="M10.6 29.9c-.9-2.6-1.5-5.4-1.5-8.3s.6-5.7 1.5-8.3L1.7 6.4C.6 8.6 0 11.2 0 14c0 2.8.6 5.5 1.7 7.8l8.9 7.9z" />
              <path fill="#34A853" d="M24 48c6.6 0 12.6-2.2 17.3-6l-8.7-6.7c-2.5 1.7-5.6 2.7-8.6 2.7-5.4 0-10.1-2.5-13.1-6.1l-8.9 6.9C6.9 43.3 14.7 48 24 48z" />
            </svg>
            {isLoading ? 'Connecting...' : 'Continue with Google'}
          </button>

          {/* Divider */}
          <div className="flex items-center gap-4 mb-6">
            <div className="flex-1 h-[1px] bg-white/10" />
            <span className="text-white/40 text-sm">or</span>
            <div className="flex-1 h-[1px] bg-white/10" />
          </div>
          <form onSubmit={handleSubmit} className="flex-1 flex flex-col justify-start space-y-4 md:space-y-6">
            <div className="text-center">
              <h1 className="text-3xl md:text-4xl leading-tight font-extrabold text-white mb-2 tracking-tight">Create your Account!</h1>
              <p className="text-white/50 text-sm">Please fill in your Details below.</p>
            </div>

            {/* Full Name */}
            <div>
              <label className="text-sm text-white/60 mb-2 inline-block font-medium">Full Name</label>
              <input
                type="text"
                placeholder="Your Full Name"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full px-4 py-3 md:px-6 md:py-4 rounded-[34px] bg-[#0b0b0d] text-white/60 placeholder-white/30 text-sm outline-none transition-all duration-200 border border-white/10 shadow-inner"
                style={{
                  borderWidth: 1.5,
                  boxShadow: 'inset 0 1px 0 rgba(255,255,255,0.02)',
                }}
              />
            </div>

            {/* Email */}
            <div>
              <label className="text-sm text-white/60 mb-2 inline-block font-medium">Email Address</label>
              <input
                type="email"
                placeholder="Your Email Address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 md:px-6 md:py-4 rounded-[34px] bg-[#0b0b0d] text-white/60 placeholder-white/30 text-sm outline-none transition-all duration-200 border border-white/10 shadow-inner"
                style={{ borderWidth: 1.5 }}
              />
            </div>

            {/* Phone Number */}
            <div>
              <label className="text-sm text-white/60 mb-2 inline-block font-medium">Phone Number</label>
              <input
                type="tel"
                placeholder="Phone Number"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-4 py-3 md:px-6 md:py-4 rounded-[34px] bg-[#0b0b0d] text-white/60 placeholder-white/30 text-sm outline-none transition-all duration-200 border border-white/10 shadow-inner"
                style={{ borderWidth: 1.5 }}
              />
            </div>

            {/* Message */}
            <div>
              <label className="text-sm text-white/60 mb-2 inline-block font-medium">How can we help you?</label>
              <textarea
                placeholder="How can we help you?"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={6}
                className="w-full px-4 py-3 md:px-6 md:py-4 rounded-[28px] bg-[#0b0b0d] text-white/60 placeholder-white/30 text-sm outline-none transition-all duration-200 border border-white/10 resize-none shadow-inner"
                style={{ minHeight: 140, borderWidth: 1.5 }}
              />
            </div>

            {formError && <div className="text-sm text-red-400 text-center">{formError}</div>}

            {/* Submit Button */}
            <div className="flex justify-center pt-4 md:pt-6">
              <button
                type="submit"
                disabled={isLoading}
                className="inline-flex items-center justify-center w-36 md:w-40 h-10 md:h-11 rounded-full bg-gradient-to-br from-[#ff8a1a] to-[#ff6c00] text-white font-semibold text-base transition-all duration-200 shadow-[0_14px_48px_rgba(249,115,22,0.36)]"
                style={{ letterSpacing: 0.2 }}
              >
                {isLoading ? 'Saving…' : 'Submit'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
