'use client';

import { useState } from 'react';
import { 
  Settings, 
  Bell, 
  ChevronDown, 
  ArrowUpRight, 
  ArrowDownLeft, 
  RefreshCw,
  Home,
  Wallet,
  BarChart3,
  ShoppingBag,
  TrendingUp,
  TrendingDown
} from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useFirebaseAuth } from '@/contexts/firebase-auth';
import { useRouter } from 'next/navigation';

// Crypto icons as simple SVG components
const BitcoinIcon = () => (
  <svg viewBox="0 0 24 24" className="w-6 h-6" fill="#F7931A">
    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13h-1v1h-1v-1h-1v6h1v1h1v-1h1c1.1 0 2-.9 2-2v-2c0-1.1-.9-2-2-2zm0 4h-1V9h1c.55 0 1 .45 1 1v2c0 .55-.45 1-1 1z"/>
  </svg>
);

const BNBIcon = () => (
  <div className="w-6 h-6 rounded-full bg-[#F3BA2F] flex items-center justify-center">
    <svg viewBox="0 0 24 24" className="w-4 h-4" fill="#1E2026">
      <path d="M12 2L7 7l2 2 3-3 3 3 2-2-5-5zm-5 5l-2 2 2 2 2-2-2-2zm10 0l-2 2 2 2 2-2-2-2zM12 9l-3 3 3 3 3-3-3-3zm-5 5l-2 2 5 5 5-5-2-2-3 3-3-3z"/>
    </svg>
  </div>
);

const CardanoIcon = () => (
  <div className="w-6 h-6 rounded-full bg-[#0033AD] flex items-center justify-center">
    <span className="text-white text-xs font-bold">₳</span>
  </div>
);

const TetherIcon = () => (
  <div className="w-6 h-6 rounded-full bg-[#26A17B] flex items-center justify-center">
    <span className="text-white text-xs font-bold">₮</span>
  </div>
);

// Mini sparkline chart component
const SparklineChart = ({ trend, color }: { trend: 'up' | 'down'; color: string }) => (
  <svg viewBox="0 0 50 20" className="w-12 h-5">
    <path
      d={trend === 'up' 
        ? "M0,15 L8,12 L16,14 L24,8 L32,10 L40,5 L50,3" 
        : "M0,5 L8,8 L16,6 L24,12 L32,10 L40,15 L50,17"}
      fill="none"
      stroke={color}
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export default function WalletDashboard() {
  const router = useRouter();
  const [selectedCurrency, setSelectedCurrency] = useState('USD');
  const [activeTab, setActiveTab] = useState('wallet');

  const recommendedCryptos = [
    { symbol: 'BNB', icon: <BNBIcon />, change: '+1.37', value: '216.3', trend: 'up' as const },
    { symbol: 'ADL', icon: <CardanoIcon />, change: '+2.72', value: '0.4976', trend: 'up' as const },
  ];

  const myAssets = [
    { 
      name: 'Bitcoin', 
      symbol: 'BTC',
      icon: <BitcoinIcon />,
      value: '$4,500.00', 
      change: '-4.5%',
      changeAmount: '$12.5',
      quantity: '0.0000056 BTC',
      trend: 'down' as const
    },
    { 
      name: 'Tether', 
      symbol: 'USDT',
      icon: <TetherIcon />,
      value: '$2,200.00', 
      change: null,
      changeAmount: null,
      quantity: null,
      trend: 'up' as const
    },
  ];

  const { user } = useFirebaseAuth();

  return (
    <div className="min-h-screen bg-black flex justify-center">
      <div className="w-full max-w-md relative bg-[#121212] min-h-screen text-white pb-24">
        
        {/* Top Navigation Bar */}
        <header className="flex items-center justify-between px-4 py-4">
          <Avatar className="w-12 h-12 border-2 border-[#2D2D2D]">
            <AvatarImage src={user?.photoURL ?? '/avatar.png'} alt={user?.displayName ?? 'User'} />
            <AvatarFallback className="bg-gradient-to-br from-orange-500 to-red-600 text-white">
              <svg viewBox="0 0 24 24" className="w-6 h-6" fill="currentColor">
                <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
              </svg>
            </AvatarFallback>
          </Avatar>
          
          <div className="flex items-center gap-2">
            <button className="w-10 h-10 rounded-lg bg-[#1E1E1E] flex items-center justify-center hover:bg-[#2D2D2D] transition-colors">
              <Settings className="w-5 h-5 text-gray-400" />
            </button>
            <button 
              onClick={() => router.push('/notifications')}
              className="w-10 h-10 rounded-lg bg-[#2D2D2D] flex items-center justify-center hover:bg-[#3D3D3D] transition-colors relative"
            >
              <Bell className="w-5 h-5 text-[#F97316]" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-[#F97316] rounded-full"></span>
            </button>
          </div>
        </header>

        {/* Wallet Summary Card */}
        <section className="px-4 mt-2">
          <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-[#F97316] via-[#FB923C] to-[#FDBA74] p-6">
            {/* Decorative circles */}
            <div className="absolute -left-10 -bottom-10 w-40 h-40 rounded-full bg-white/10"></div>
            <div className="absolute -left-5 bottom-0 w-24 h-24 rounded-full bg-white/10"></div>
            
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white/90 text-sm font-medium">My Wallet</span>
                <button className="flex items-center gap-1 px-3 py-1 rounded-full bg-white/20 text-white text-sm">
                  {selectedCurrency}
                  <ChevronDown className="w-4 h-4" />
                </button>
              </div>
              
              <h2 className="text-4xl font-bold text-white tracking-tight mb-6">
                $8,540.00
              </h2>
              
              {/* Action Buttons */}
              <div className="flex gap-3">
                <button className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-white/20 backdrop-blur-sm text-white text-sm font-medium hover:bg-white/30 transition-colors">
                  <ArrowUpRight className="w-4 h-4" />
                  Transfer
                </button>
                <button className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-white/30 backdrop-blur-sm text-white text-sm font-medium hover:bg-white/40 transition-colors">
                  <ArrowDownLeft className="w-4 h-4" />
                  Deposit
                </button>
                <button className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-white/30 backdrop-blur-sm text-white text-sm font-medium hover:bg-white/40 transition-colors">
                  <RefreshCw className="w-4 h-4" />
                  Swap
                </button>
              </div>
            </div>
          </div>
        </section>

        {/* Market Snapshot - BTC */}
        <section className="px-4 mt-6">
          <div className="flex items-center justify-between p-4 rounded-xl bg-[#1E1E1E]">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[#2D2D2D] flex items-center justify-center">
                <BitcoinIcon />
              </div>
              <span className="font-semibold text-white">BTC</span>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-[#10B981] font-medium">0.00000045</span>
              <SparklineChart trend="up" color="#10B981" />
              <span className="text-[#10B981] font-medium">3.8%</span>
            </div>
          </div>
        </section>

        {/* Recommended Section */}
        <section className="px-4 mt-6">
          <h3 className="text-gray-400 text-sm font-medium mb-4">Recommended</h3>
          <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
            {recommendedCryptos.map((crypto) => (
              <div 
                key={crypto.symbol}
                className="flex-shrink-0 w-44 p-4 rounded-xl bg-[#1E1E1E] border border-[#2D2D2D]"
              >
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    {crypto.icon}
                    <span className="font-semibold text-white">{crypto.symbol}</span>
                  </div>
                  <SparklineChart trend={crypto.trend} color="#10B981" />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-[#10B981] font-medium">{crypto.change}</span>
                  <span className="text-gray-400">{crypto.value}</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* My Assets Section */}
        <section className="px-4 mt-6">
          <h3 className="text-gray-400 text-sm font-medium mb-4">My Assets</h3>
          <div className="space-y-3">
            {myAssets.map((asset) => (
              <div 
                key={asset.symbol}
                className="flex items-center justify-between p-4 rounded-xl bg-[#1E1E1E] border border-[#2D2D2D]"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#2D2D2D] flex items-center justify-center">
                    {asset.icon}
                  </div>
                  <div>
                    <span className="font-semibold text-white block">{asset.name}</span>
                    {asset.change && (
                      <div className="flex items-center gap-2 mt-1">
                        <SparklineChart 
                          trend={asset.trend} 
                          color={asset.trend === 'up' ? '#10B981' : '#EF4444'} 
                        />
                        <span className={`text-sm ${asset.trend === 'up' ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                          {asset.change}
                        </span>
                        <span className="text-gray-400 text-sm">{asset.changeAmount}</span>
                      </div>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-semibold text-white block">{asset.value}</span>
                  {asset.quantity && (
                    <span className="text-gray-400 text-sm">{asset.quantity}</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Bottom Navigation Bar */}
        <nav className="fixed bottom-0 left-0 right-0 bg-[#121212] border-t border-[#2D2D2D] px-8 py-4">
          <div className="flex items-center justify-between max-w-md mx-auto">
            <button 
              onClick={() => setActiveTab('home')}
              className={`flex flex-col items-center gap-1 transition-colors relative ${
                activeTab === 'home' ? 'text-[#F97316]' : 'text-gray-500'
              }`}
            >
              {activeTab === 'home' && (
                <span className="absolute -top-2 w-1 h-1 bg-[#10B981] rounded-full"></span>
              )}
              <Home className="w-6 h-6" />
            </button>
            <button 
              onClick={() => setActiveTab('wallet')}
              className={`flex flex-col items-center gap-1 transition-colors relative ${
                activeTab === 'wallet' ? 'text-[#F97316]' : 'text-gray-500'
              }`}
            >
              {activeTab === 'wallet' && (
                <span className="absolute -top-2 w-1 h-1 bg-[#10B981] rounded-full"></span>
              )}
              <Wallet className="w-6 h-6" />
            </button>
            <button 
              onClick={() => setActiveTab('analytics')}
              className={`flex flex-col items-center gap-1 transition-colors ${
                activeTab === 'analytics' ? 'text-[#F97316]' : 'text-gray-500'
              }`}
            >
              <BarChart3 className="w-6 h-6" />
            </button>
            <button 
              onClick={() => setActiveTab('shop')}
              className={`flex flex-col items-center gap-1 transition-colors ${
                activeTab === 'shop' ? 'text-[#F97316]' : 'text-gray-500'
              }`}
            >
              <ShoppingBag className="w-6 h-6" />
            </button>
          </div>
        </nav>
      </div>
    </div>
  );
}
