
'use client';

import { useState } from 'react';
import Link from 'next/link';
import { ChevronLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';

export default function TransferPage() {
  const router = useRouter();
  const [receiver, setReceiver] = useState('');
  const [amount, setAmount] = useState('');

  const handleSend = () => {
    // In a real app, you'd validate and process this
    // For now, we'll just navigate to the PIN screen
    router.push('/transfer/confirm');
  };

  return (
    <div className="flex min-h-screen w-full flex-col bg-background">
      <header className="container mx-auto max-w-md flex items-center justify-between py-6 px-4">
        <Link href="/" className="z-10">
          <Button variant="ghost" size="icon" className="rounded-lg h-10 w-10">
            <ChevronLeft className="h-6 w-6" />
          </Button>
        </Link>
        <h1 className="text-xl font-bold absolute left-1/2 -translate-x-1/2">
          Send Money
        </h1>
      </header>
      <main className="flex-1">
        <div className="container mx-auto max-w-md space-y-8 px-4">
          <Card className="bg-card border-none">
            <CardContent className="p-6 space-y-6">
              <div className="space-y-2">
                <Label htmlFor="receiver-number">Receiver Number</Label>
                <Input
                  id="receiver-number"
                  placeholder="Enter receiver's number"
                  value={receiver}
                  onChange={(e) => setReceiver(e.target.value)}
                  className="bg-zinc-800 border-zinc-700 h-12"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="amount">Amount</Label>
                <Input
                  id="amount"
                  type="number"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="bg-zinc-800 border-zinc-700 h-12 text-2xl font-bold"
                />
              </div>
            </CardContent>
          </Card>
          <Button onClick={handleSend} className="w-full bg-primary h-12 text-base font-bold text-black hover:bg-primary/90">
            Send
          </Button>
        </div>
      </main>
    </div>
  );
}
