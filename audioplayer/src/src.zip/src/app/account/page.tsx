"use client";

import React, { useEffect, useState } from 'react';
import { useFirebaseAuth } from '@/contexts/firebase-auth';
import { getUserProfile, UserProfile } from '@/lib/user';
import Link from 'next/link';

export default function AccountPage() {
  const { user } = useFirebaseAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    (async () => {
      setLoading(true);
      const doc = await getUserProfile(user.uid);
      setProfile(doc);
      setLoading(false);
    })();
  }, [user]);

  if (!user) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center text-white">
        <div>
          <p>Please sign in to view your account.</p>
          <Link href="/signup" className="text-orange-400 underline">Sign in</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black p-6">
      <div className="max-w-3xl mx-auto bg-[#0B0B0C] border border-white/5 rounded-3xl p-8 text-white">
        <header className="flex items-center gap-4 mb-6">
          <div className="relative flex shrink-0 overflow-hidden h-20 w-20 rounded-lg bg-purple-600/20">
            <img className="aspect-square h-full w-full p-1 rounded-lg" src={user.photoURL ?? profile?.photoURL ?? ''} alt={user.displayName ?? 'User'} />
          </div>
          <div>
            <h1 className="text-xl font-semibold">{profile?.displayName ?? user.displayName ?? 'User'}</h1>
            <div className="text-sm text-white/60">{profile?.email ?? user.email}</div>
          </div>
        </header>

        {loading ? (
          <div>Loading…</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 border border-white/5 rounded-lg">
              <h3 className="text-sm text-white/80 font-medium">First name</h3>
              <div className="mt-2 text-white">{profile?.firstName ?? '-'}</div>
            </div>

            <div className="p-4 border border-white/5 rounded-lg">
              <h3 className="text-sm text-white/80 font-medium">Last name</h3>
              <div className="mt-2 text-white">{profile?.lastName ?? '-'}</div>
            </div>

            <div className="p-4 border border-white/5 rounded-lg">
              <h3 className="text-sm text-white/80 font-medium">Country</h3>
              <div className="mt-2 text-white">{profile?.country ?? '-'}</div>
            </div>

            <div className="p-4 border border-white/5 rounded-lg">
              <h3 className="text-sm text-white/80 font-medium">WhatsApp</h3>
              <div className="mt-2 text-white">{profile?.whatsapp ?? '-'}</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
