"use client";

import { getSdks } from '@/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';

export type UserProfile = {
  uid: string;
  firstName?: string;
  lastName?: string;
  country?: string;
  whatsapp?: string;
  displayName?: string | null;
  email?: string | null;
  photoURL?: string | null;
  createdAt?: string;
  updatedAt?: string;
};

const getUsersCollectionDoc = (uid: string) => {
  const { firestore } = getSdks();
  return doc(firestore, 'users', uid);
};

export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  try {
    const d = await getDoc(getUsersCollectionDoc(uid));
    if (!d.exists()) return null;
    return d.data() as UserProfile;
  } catch (err) {
    console.error('getUserProfile error', err);
    return null;
  }
}

export async function setUserProfile(uid: string, data: Partial<UserProfile>): Promise<void> {
  try {
    const now = new Date().toISOString();
    await setDoc(getUsersCollectionDoc(uid), {
      ...data,
      uid,
      updatedAt: now,
      createdAt: data.createdAt ?? now,
    }, { merge: true });
  } catch (err) {
    console.error('setUserProfile error', err);
    throw err;
  }
}
