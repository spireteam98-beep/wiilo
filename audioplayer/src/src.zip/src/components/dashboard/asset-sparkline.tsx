'use client';

import { Area, AreaChart, ResponsiveContainer, Tooltip } from 'recharts';
import { ChartContainer, ChartTooltipContent, type ChartConfig } from '@/components/ui/chart';

interface AssetSparklineProps {
  data: { name: string; value: number }[];
  trend: 'up' | 'down';
}

const chartConfig = {
  value: {
    label: 'Value',
  },
} satisfies ChartConfig;

export default function AssetSparkline({ data, trend }: AssetSparklineProps) {
  const color = trend === 'up' ? 'hsl(142.1 76.2% 41.2%)' : 'hsl(0 84.2% 60.2%)';
  const gradientId = `sparkline-gradient-${trend}`;

  return (
    <ChartContainer config={chartConfig} className="h-full w-full">
      <AreaChart
        accessibilityLayer
        data={data}
        margin={{
          top: 5,
          right: 0,
          left: 0,
          bottom: 5,
        }}
      >
        <defs>
          <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor={color} stopOpacity={0.4} />
            <stop offset="95%" stopColor={color} stopOpacity={0} />
          </linearGradient>
        </defs>
        <Tooltip
          content={<ChartTooltipContent 
            indicator="dot"
            hideLabel
            formatter={(value) => new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(value as number)}
          />}
          cursor={{ stroke: 'hsl(var(--muted-foreground))', strokeWidth: 1, strokeDasharray: '3 3' }}
        />
        <Area
          type="monotone"
          dataKey="value"
          stroke={color}
          strokeWidth={2}
          fillOpacity={1}
          fill={`url(#${gradientId})`}
        />
      </AreaChart>
    </ChartContainer>
  );
}
